# project-1

This repository contains the necessary notebooks for project 1. For instructions please refer to bcourses.
